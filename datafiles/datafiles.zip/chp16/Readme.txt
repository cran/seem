format for input data to semi.f
i7                           number states  
f7.2 i7 f7.2                 dt, time for print/plot,tfinal
f7.3  f7.3 .... f7.3         initial condition        
f7.3  f7.3 .... f7.3         matrix of probabilities
f7.3  f7.3 .... f7.3                      p(i,j)    j to i
  .    .         .            nxn
  .    .         .        
f7.3  f7.3 .... f7.3      
i7    i7   .... i7           matrix of order of distrib lags
i7    i7   .... i7                        k(i,j)    j to i
 .    .          .
 .    .          .            nxn
i7    i7   .... i7
f7.2  f7.2 .... f7.2         matrix of means of distrib lags
f7.2  f7.2 .... f7.2                     av(i,j)    j to i
  .    .         .            nxn
  .    .         .
f7.2  f7.2 .... f7.2
f7.2  f7.2 .... f7.2         matrix of order of fixed lags
f7.2  f7.2 .... f7.2                     qd(i,j)    j to i
  .    .         .            nxn
  .    .         .
f7.2  f7.2 .... f7.2
